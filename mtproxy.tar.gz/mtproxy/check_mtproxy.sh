#!/bin/bash

cd /home/mtproxy || exit 1

# 检查 mtg 是否运行中（避免误匹配其他命令）
if pgrep -f "[./]mtg run" > /dev/null; then
    echo "✅ mtg 已在运行，跳过启动。"
else
    echo "⚠️ mtg 未运行，正在尝试启动..."
    # 建议先赋予执行权限
    chmod +x ./mtproxy.sh 2>/dev/null
    nohup bash ./mtproxy.sh start > /home/mtproxy/mtproxy.log 2>&1 &
    echo "✅ mtg 启动命令已执行，日志写入 /mtproxy.log"
fi
